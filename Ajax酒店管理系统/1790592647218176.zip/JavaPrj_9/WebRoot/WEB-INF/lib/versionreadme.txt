=====================dev-tools==============================
JDK:
	jdk-6-windows-i586.exe
Eclipse:
	eclipse-SDK-3.3RC3
MyEclipse:
	MyEclipse_6.0GA_E3.3
Tomcat:
	Tomcat6.0.14
Mysql: mysql-essential-5.0.45-win32
	
=====================framework===============================
Ext:
	ext-2.0.2
DWR:
	dwr2.0.3
Spring(spring-framework-2.0.7):
	spring.jar
	spring-mock.jar ����Junit
hibernate-3.2.6.ga:
	hibernate3.jar
	antlr-2.7.6.jar
	asm
	asm-attrs.jar
	cglib-2.1.3.jar
	commons-collections-2.1.1.jar
	commons-logging-1.0.4.jar
	dom4j-1.6.1.jar
	ehcache-1.2.3.jar
	jta
	log4j-1.2.14
	hibernate-annotations.jar(3.3.1.GA): ejb3-persistence.jar,hibernate-commons-annotations.jar
	hibernate-validator.jar(3.0.0.GA)
	mysql-connector-java-5.1.6-bin.jar
Log4j:	
	log4j-1.2.14
commons-logging:
	spring "jakarta-commons/"��
Junit:junit.jar

JSON:	json-lib-2.2.1-jdk15.jar 
	(������:
	jakarta commons-lang 2.3 
	jakarta commons-lang 2.3 
	jakarta commons-beanutils 1.7.0 
	jakarta commons-collections 3.2 
	jakarta commons-logging 1.1 
	ezmorph 1.0.4 
	)
	json-lib-ext-spring-1.0.jar