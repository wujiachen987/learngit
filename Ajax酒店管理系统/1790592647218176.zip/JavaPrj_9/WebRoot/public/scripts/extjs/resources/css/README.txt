2006-11-21 jvs:
ext-all.css contains all of the other css files combined and stripped of comments (except themes).

