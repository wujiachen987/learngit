package com.hotelmaster.dao;

import com.hotelmaster.po.CheckinItem;

public interface CheckinItemDao extends GenericDao<CheckinItem>{
		
}
