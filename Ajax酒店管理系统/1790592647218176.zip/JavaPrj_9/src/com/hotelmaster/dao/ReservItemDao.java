package com.hotelmaster.dao;

import com.hotelmaster.po.ReservItem;

public interface ReservItemDao extends GenericDao<ReservItem>{

}
